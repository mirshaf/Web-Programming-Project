package com.example.questionplatform.response;

public interface Response {
}
