package com.example.questionplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuestionPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuestionPlatformApplication.class, args);
	}

}
