package com.example.questionplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestionPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
